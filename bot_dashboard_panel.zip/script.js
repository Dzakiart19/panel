
document.getElementById('uploadForm').addEventListener('submit', function(e) {
  e.preventDefault();
  const formData = new FormData(this);
  fetch('/upload-script', {
    method: 'POST',
    body: formData,
  })
  .then(res => res.json())
  .then(data => alert(data.message))
  .catch(err => alert('Gagal mengupload script.'));
});

function setBotStatus(isOn) {
  fetch('/bot-status', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({status: isOn})
  })
  .then(res => res.json())
  .then(data => {
    document.getElementById('botStatus').textContent = isOn ? "ON" : "OFF";
    alert(data.message);
  });
}
