
const express = require('express');
const multer = require('multer');
const path = require('path');
const app = express();
const upload = multer({ dest: 'uploads/' });

app.use(express.static(__dirname));
app.use(express.json());

app.post('/upload-script', upload.single('scriptFile'), (req, res) => {
  res.json({ message: 'Script berhasil diupload dan akan dijalankan.' });
});

app.post('/bot-status', (req, res) => {
  const { status } = req.body;
  res.json({ message: `Bot telah ${status ? 'diaktifkan' : 'dimatikan'}.` });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Dashboard aktif di http://localhost:${PORT}`));
